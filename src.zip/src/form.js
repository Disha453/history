import { useState } from "react";

const ReactForm = () => {
    const [uname, setUname] = useState("");
    const [email, setEmail] = useState("fsgdfh@ghg.ghgh");
    const [gender, setGender] = useState("");

    console.log(uname);
    console.log(email);
    console.log(gender);

    return (
        <>
            <h1>Form</h1>
            <div>
                <label htmlFor="uname">Username</label>
                <input type="text" id="uname" name="uname" value={uname} onChange={(t) => setUname(t.target.value)} />
            </div>
            <div>
                <label htmlFor="email">Email</label>
                <input type="email" id="email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div>
                <label htmlFor="gender">Gender</label>
                <input type="radio" name="gender" id="male" value="Male" onChange={(e) => setGender(e.target.value)} />Male
                <input type="radio" name="gender" id="female" value="female" onChange={(e) => setGender(e.target.value)} />female
            </div>

        </>
    )
}

export default ReactForm;