import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  const [student, setStudent] = useState({ uname: "", email: "", gender: "" });
  const [data, setData] = useState([])

  const handleChange = (e) => {
    console.log(e.target.name)
    setStudent({ ...student, [e.target.name]: e.target.value })
  }



  const handleSubmit = () => {
    setData([...data, student])
  }
  console.log(student)
  console.log(data)
  return (

    <div>
      <h1>Objects</h1>
      <div>
        <label htmlFor="uname">Username</label>
        <input type="text" id="uname" name="uname" value={student.uname} onChange={(e) => handleChange(e)} />
      </div>
      <div>
        <label htmlFor="email">Email</label>
        <input type="email" id="email" name="email" value={student.email} onChange={(e) => handleChange(e)} />
      </div>
      <div>
        <label htmlFor="gender">Gender</label>
        <input type="radio" name="gender" id="male" value="Male" onChange={(e) => handleChange(e)} />Male
        <input type="radio" name="gender" id="female" value="female" onChange={(e) => handleChange(e)} />female
      </div>
      <button type='submit' onClick={() => handleSubmit()}>Submit</button>
    </div>
  );
}

export default App;
